document.addEventListener("DOMContentLoaded", function () {
    const toggle = document.getElementById("dark-mode");
    toggle.addEventListener("change", function () {
        document.body.classList.toggle("dark");
    });
});
