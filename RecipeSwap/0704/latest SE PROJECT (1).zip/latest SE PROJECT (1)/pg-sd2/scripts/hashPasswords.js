const bcrypt = require('bcryptjs');
const db = require('../app/services/db'); // adjust path if needed

async function hashAllPasswords() {
  try {
    const [users] = await db.query('SELECT user_ID, user_password FROM users');

    for (const user of users) {
      const currentPassword = user.user_password;

      // Check if it's already hashed (very rough check - hashed passwords start with $2)
      if (!currentPassword.startsWith('$2')) {
        const hashed = await bcrypt.hash(currentPassword, 10);
        await db.query('UPDATE users SET user_password = ? WHERE user_ID = ?', [hashed, user.user_ID]);
        console.log(`✅ Updated password for user_ID ${user.user_ID}`);
      } else {
        console.log(`🔒 Password already hashed for user_ID ${user.user_ID}`);
      }
    }

    console.log('\n🎉 All passwords updated!');
    process.exit();
  } catch (err) {
    console.error('❌ Error hashing passwords:', err);
    process.exit(1);
  }
}

hashAllPasswords();
