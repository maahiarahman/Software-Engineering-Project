document.getElementById("review-form").addEventListener("submit", function (event) {
    event.preventDefault();
    
    const recipeName = document.getElementById("recipe-name").value;
    const reviewText = document.getElementById("review-text").value;
    
    console.log("New Review Submitted:", recipeName, reviewText);
    alert("Your review has been posted!");
});
