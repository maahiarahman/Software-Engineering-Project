document.addEventListener("DOMContentLoaded", () => {
    const offerButtons = document.querySelectorAll(".offer-swap");
    const hiddenRecipeInput = document.getElementById("recipe_2");
    const displayField = document.getElementById("swapWith");
  
    offerButtons.forEach(button => {
      button.addEventListener("click", () => {
        const recipeId = button.getAttribute("data-id");
        const recipeName = button.getAttribute("data-name");
  
        hiddenRecipeInput.value = recipeId;
        displayField.value = recipeName;
  
        // Scroll to form
        const form = document.getElementById("swapForm");
        form?.scrollIntoView({ behavior: "smooth" });
      });
    });
  });
  document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector(".swap-form");
    const yourRecipeSelect = document.querySelector("select[name='your_recipe_id']");
    const desiredRecipeSelect = document.querySelector("select[name='desired_recipe_id']");
    const submitBtn = form.querySelector("button[type='submit']");
  
    const showToast = (message, type = "success") => {
      const toast = document.createElement("div");
      toast.className = `toast ${type}`;
      toast.textContent = message;
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 4000);
    };
  
    form?.addEventListener("submit", (e) => {
      e.preventDefault();
  
      const yourRecipe = yourRecipeSelect?.value;
      const desiredRecipe = desiredRecipeSelect?.value;
  
      if (!yourRecipe || !desiredRecipe) {
        showToast("Please select both your recipe and the one you want to receive.", "error");
        return;
      }
  
      const formData = new URLSearchParams();
      formData.append("your_recipe_id", yourRecipe);
      formData.append("desired_recipe_id", desiredRecipe);
  
      fetch("/swap", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: formData
      })
        .then((res) => {
          if (!res.ok) throw new Error("Server error");
          return res.text();
        })
        .then(() => {
          showToast("Swap request submitted successfully!");
          form.reset();
        })
        .catch((err) => {
          console.error(err);
          showToast("Failed to submit swap request.", "error");
        });
    });
  });
  