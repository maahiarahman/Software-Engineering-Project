document.getElementById("recipe-form").addEventListener("submit", function (event) {
    event.preventDefault();
    const recipeName = document.getElementById("recipe-name").value;
    const recipeDescription = document.getElementById("recipe-description").value;
    
    console.log("Recipe Posted:", recipeName, recipeDescription);
    alert("Your recipe has been posted!");
});
