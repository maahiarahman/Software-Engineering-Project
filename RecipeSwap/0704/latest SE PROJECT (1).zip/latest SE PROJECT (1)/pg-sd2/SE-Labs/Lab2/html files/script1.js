// script1.js
document.write("Hello, world!");
